| Supported Targets | ESP32-S2 |
| ----------------- | -------- | 

# Important

* This is an ESP-IDF project. Not PlatformIO or Arduino.
* Proof of concept using the ESP32-S2 - WeMos S2 Mini!